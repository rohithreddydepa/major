$(document).on("change", ".file-input", function () {
  var textbox = $(this).prev();
  var fileName = $(this).val().split("\\").pop();
  textbox.text(fileName);
});
